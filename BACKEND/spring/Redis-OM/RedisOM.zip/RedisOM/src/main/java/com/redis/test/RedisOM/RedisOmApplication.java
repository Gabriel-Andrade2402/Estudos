package com.redis.test.RedisOM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisOmApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedisOmApplication.class, args);
	}

}
